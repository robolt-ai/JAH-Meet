const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const HOST_PASSWORD = 'host123';
const VIEWER_PASSWORD = 'view123';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

let hosts = new Set();
let viewers = new Set();
let questionsOpen = false;

io.on('connection', socket => {

  socket.on('join', ({ role, password }) => {

    if (role === 'host') {
      if (password !== HOST_PASSWORD) {
        socket.emit('join-error', 'Invalid host password');
        return;
      }
      socket.role = 'host';
      hosts.add(socket.id);
      socket.emit('joined-host');
      socket.emit('questions-status', questionsOpen);
      io.emit('viewer-count', viewers.size);
    }

    if (role === 'viewer') {
      if (password !== VIEWER_PASSWORD) {
        socket.emit('join-error', 'Invalid viewer password');
        return;
      }
      socket.role = 'viewer';
      viewers.add(socket.id);
      socket.emit('joined-viewer');
      socket.emit('questions-status', questionsOpen);
      io.emit('viewer-count', viewers.size);

      hosts.forEach(h =>
        io.to(h).emit('viewer-ready', socket.id)
      );
    }
  });

  socket.on('offer', ({ viewerId, sdp }) => {
    io.to(viewerId).emit('offer', { hostId: socket.id, sdp });
  });

  socket.on('answer', ({ hostId, sdp }) => {
    io.to(hostId).emit('answer', { viewerId: socket.id, sdp });
  });

  socket.on('ice', ({ target, candidate }) => {
    io.to(target).emit('ice', { from: socket.id, candidate });
  });

  socket.on('toggle-mic', muted => {
    io.emit('host-mic', { hostId: socket.id, muted });
  });

  socket.on('toggle-questions', () => {
    if (socket.role !== 'host') return;
    questionsOpen = !questionsOpen;
    io.emit('questions-status', questionsOpen);
  });

  socket.on('submit-question', text => {
    if (!questionsOpen || socket.role !== 'viewer') return;
    hosts.forEach(h => io.to(h).emit('new-question', { text }));
  });

  socket.on('leave-meet', () => {
    if (hosts.has(socket.id)) {
      hosts.delete(socket.id);
      io.emit('host-left', socket.id);
    }
    if (viewers.has(socket.id)) {
      viewers.delete(socket.id);
      io.emit('viewer-count', viewers.size);
    }
  });

  socket.on('end-meeting', () => {
    io.emit('meeting-ended');
    hosts.clear();
    viewers.clear();
    questionsOpen = false;
    io.emit('viewer-count', 0);
  });

  socket.on('disconnect', () => {
    if (hosts.has(socket.id)) {
      hosts.delete(socket.id);
      io.emit('host-left', socket.id);
    }
    if (viewers.has(socket.id)) {
      viewers.delete(socket.id);
      io.emit('viewer-count', viewers.size);
    }
  });
});

server.listen(3000, () =>
  console.log('Server running on port 3000')
);
